MARYANN'S SALON & BARBERSHOP

This version is self-contained: all website images are embedded directly in index.html, so they will display even when the HTML file is opened by itself.

Open index.html in Chrome, Firefox, Edge, or Safari. No separate images folder is required.
